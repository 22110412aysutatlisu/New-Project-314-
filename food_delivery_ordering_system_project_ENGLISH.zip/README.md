# Food Delivery Ordering System - CMPE314

A simple full-stack Food Delivery Ordering System built with Node.js, Express, EJS, and MySQL.

## Features

- User registration and login
- Customer menu browsing and search
- Shopping cart
- Order placement with payment simulation
- Restaurant panel for order status updates
- Menu availability / out-of-stock toggle
- Admin panel for restaurant management
- MySQL database setup script

## Requirements

- Node.js
- MySQL Server or XAMPP MySQL

## Setup

1. Extract the project folder.
2. Open terminal in the project folder.
3. Install packages:

```bash
npm install
```

4. Copy `.env.example` to `.env`. For XAMPP default MySQL, this usually works:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=food_delivery_system
SESSION_SECRET=cmpe314_secret
PORT=3000
```

5. Make sure MySQL is running.
6. Create and seed database:

```bash
npm run db:setup
```

7. Start the project:

```bash
npm start
```

8. Open:

```text
http://localhost:3000
```

## Demo Accounts

- Customer: `customer@demo.com` / `123456`
- Restaurant: `restaurant@demo.com` / `123456`
- Admin: `admin@demo.com` / `123456`

## Notes

This is a student project prototype. Online payment is implemented as a simulation, not a real payment gateway.
