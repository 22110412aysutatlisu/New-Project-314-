const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const DB_NAME = process.env.DB_NAME || 'food_delivery_system';

async function main() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  await connection.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`; USE \`${DB_NAME}\`;`);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      full_name VARCHAR(100) NOT NULL,
      email VARCHAR(120) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('customer','restaurant','admin') NOT NULL DEFAULT 'customer',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS restaurants (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      cuisine VARCHAR(80) NOT NULL,
      address VARCHAR(255) NOT NULL
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      restaurant_id INT NOT NULL,
      name VARCHAR(120) NOT NULL,
      category VARCHAR(80) NOT NULL,
      description TEXT,
      price DECIMAL(10,2) NOT NULL,
      available BOOLEAN DEFAULT TRUE,
      FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      customer_id INT NOT NULL,
      total_amount DECIMAL(10,2) NOT NULL,
      payment_method VARCHAR(60) NOT NULL,
      address VARCHAR(255) NOT NULL,
      status ENUM('Pending','Preparing','On The Way','Delivered') DEFAULT 'Pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      order_id INT NOT NULL,
      menu_item_id INT NOT NULL,
      quantity INT NOT NULL,
      unit_price DECIMAL(10,2) NOT NULL,
      notes VARCHAR(255),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
    );
  `);

  const hash = await bcrypt.hash('123456', 10);
  await connection.query('INSERT IGNORE INTO users(id,full_name,email,password_hash,role) VALUES (1,?,?,?,?), (2,?,?,?,?), (3,?,?,?,?)', [
    'Demo Customer','customer@demo.com',hash,'customer',
    'Demo Restaurant','restaurant@demo.com',hash,'restaurant',
    'Demo Admin','admin@demo.com',hash,'admin'
  ]);

  await connection.query(`INSERT IGNORE INTO restaurants(id,name,cuisine,address) VALUES
    (1,'Pizza Palace','Italian','Nicosia Center'),
    (2,'Burger House','Fast Food','Famagusta'),
    (3,'Sushi Corner','Japanese','Kyrenia')`);

  await connection.query(`INSERT IGNORE INTO menu_items(id,restaurant_id,name,category,description,price,available) VALUES
    (1,1,'Margherita Pizza','Pizza','Tomato sauce, mozzarella and basil',180,1),
    (2,1,'Chicken Alfredo Pasta','Pasta','Creamy pasta with grilled chicken',210,1),
    (3,2,'Classic Burger','Burger','Beef patty, lettuce, tomato and sauce',160,1),
    (4,2,'Crispy Chicken Wrap','Wrap','Crispy chicken with fresh vegetables',135,1),
    (5,3,'Salmon Sushi Set','Sushi','8 pieces salmon sushi',250,1),
    (6,3,'Veggie Noodles','Noodles','Vegetable noodles with soy sauce',145,1)`);

  await connection.end();
  console.log(`Database '${DB_NAME}' created and seeded successfully.`);
  console.log('Demo logins: customer@demo.com / 123456 | restaurant@demo.com / 123456 | admin@demo.com / 123456');
}

main().catch(err => {
  console.error('Database setup failed:', err.message);
  process.exit(1);
});
