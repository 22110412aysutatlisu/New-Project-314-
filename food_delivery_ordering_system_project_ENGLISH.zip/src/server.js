const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const path = require('path');
const pool = require('./db');
require('dotenv').config();

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({ secret: process.env.SESSION_SECRET || 'secret', resave: false, saveUninitialized: false }));

function auth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}
function role(roleName) {
  return (req, res, next) => {
    if (!req.session.user || req.session.user.role !== roleName) return res.redirect('/login');
    next();
  };
}

app.get('/', (req, res) => res.redirect(req.session.user ? '/dashboard' : '/login'));
app.get('/login', (req, res) => res.render('login', { error: null }));
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM users WHERE email=?', [email]);
    if (!rows.length) return res.render('login', { error: 'Invalid email or password.' });
    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.render('login', { error: 'Invalid email or password.' });
    req.session.user = { id: user.id, name: user.full_name, role: user.role };
    res.redirect('/dashboard');
  } catch (err) {
    res.render('login', { error: err.message });
  }
});
app.get('/register', (req, res) => res.render('register', { error: null }));
app.post('/register', async (req, res) => {
  try {
    const { full_name, email, password, role } = req.body;
    const hash = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,?)', [full_name, email, hash, role || 'customer']);
    res.redirect('/login');
  } catch (err) {
    res.render('register', { error: err.message });
  }
});
app.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/login')));

app.get('/dashboard', auth, (req, res) => {
  if (req.session.user.role === 'restaurant') return res.redirect('/restaurant');
  if (req.session.user.role === 'admin') return res.redirect('/admin');
  return res.redirect('/menu');
});

app.get('/menu', role('customer'), async (req, res) => {
  const q = `%${req.query.q || ''}%`;
  const [items] = await pool.query(`SELECT mi.*, r.name restaurant_name FROM menu_items mi JOIN restaurants r ON r.id=mi.restaurant_id WHERE mi.available=1 AND (mi.name LIKE ? OR r.name LIKE ? OR mi.category LIKE ?) ORDER BY r.name, mi.category`, [q, q, q]);
  res.render('menu', { user: req.session.user, items, q: req.query.q || '', cart: req.session.cart || [] });
});
app.post('/cart/add', role('customer'), async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM menu_items WHERE id=? AND available=1', [req.body.item_id]);
  if (rows.length) {
    req.session.cart = req.session.cart || [];
    const item = rows[0];
    const existing = req.session.cart.find(x => x.id === item.id);
    if (existing) existing.qty += 1;
    else req.session.cart.push({ id: item.id, name: item.name, price: Number(item.price), qty: 1, notes: req.body.notes || '' });
  }
  res.redirect('/cart');
});
app.get('/cart', role('customer'), (req, res) => {
  const cart = req.session.cart || [];
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  res.render('cart', { user: req.session.user, cart, subtotal, delivery: cart.length ? 25 : 0 });
});
app.post('/cart/remove', role('customer'), (req, res) => {
  req.session.cart = (req.session.cart || []).filter(i => i.id != req.body.item_id);
  res.redirect('/cart');
});
app.post('/order/place', role('customer'), async (req, res) => {
  const cart = req.session.cart || [];
  if (!cart.length) return res.redirect('/menu');
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const total = subtotal + 25;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [orderResult] = await conn.query('INSERT INTO orders(customer_id,total_amount,payment_method,address,status) VALUES(?,?,?,?,?)', [req.session.user.id, total, req.body.payment_method || 'Cash', req.body.address || 'Not specified', 'Pending']);
    for (const item of cart) {
      await conn.query('INSERT INTO order_items(order_id,menu_item_id,quantity,unit_price,notes) VALUES(?,?,?,?,?)', [orderResult.insertId, item.id, item.qty, item.price, item.notes]);
    }
    await conn.commit();
    req.session.cart = [];
    res.redirect('/my-orders');
  } catch (e) {
    await conn.rollback();
    res.status(500).send(e.message);
  } finally { conn.release(); }
});
app.get('/my-orders', role('customer'), async (req, res) => {
  const [orders] = await pool.query('SELECT * FROM orders WHERE customer_id=? ORDER BY created_at DESC', [req.session.user.id]);
  res.render('orders', { user: req.session.user, orders });
});

app.get('/restaurant', role('restaurant'), async (req, res) => {
  const [orders] = await pool.query(`SELECT o.*, u.full_name customer_name FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.created_at DESC`);
  const [items] = await pool.query('SELECT * FROM menu_items ORDER BY category,name');
  res.render('restaurant', { user: req.session.user, orders, items });
});
app.post('/restaurant/order-status', role('restaurant'), async (req, res) => {
  await pool.query('UPDATE orders SET status=? WHERE id=?', [req.body.status, req.body.order_id]);
  res.redirect('/restaurant');
});
app.post('/restaurant/item-toggle', role('restaurant'), async (req, res) => {
  await pool.query('UPDATE menu_items SET available = NOT available WHERE id=?', [req.body.item_id]);
  res.redirect('/restaurant');
});

app.get('/admin', role('admin'), async (req, res) => {
  const [[stats]] = await pool.query('SELECT (SELECT COUNT(*) FROM users) users, (SELECT COUNT(*) FROM restaurants) restaurants, (SELECT COUNT(*) FROM orders) orders');
  const [restaurants] = await pool.query('SELECT * FROM restaurants');
  res.render('admin', { user: req.session.user, stats, restaurants });
});
app.post('/admin/restaurant', role('admin'), async (req, res) => {
  await pool.query('INSERT INTO restaurants(name,cuisine,address) VALUES(?,?,?)', [req.body.name, req.body.cuisine, req.body.address]);
  res.redirect('/admin');
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Food Delivery System running on http://localhost:${port}`));
